const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const defaultState={nickname:"Player",playerId:"",shots:0,hits:0,headshots:0,reactions:[],sessions:0,xp:0,challengeHits:0,challengeHS:0,reactionChallenge:false,sensitivity:{general:100,redDot:90,scope2:85,scope4:75,sniper:50,freeLook:70}};
let state=JSON.parse(localStorage.getItem("hsTraining")||"null")||defaultState;
function save(){localStorage.setItem("hsTraining",JSON.stringify(state));updateUI()}
function pct(a,b){return b?Math.round(a/b*100):0}
function updateUI(){
 $("#nicknameTop").textContent=state.nickname||"Player"; $("#nickname").value=state.nickname||""; $("#playerId").value=state.playerId||"";
 $("#dashAccuracy").textContent=pct(state.hits,state.shots)+"%"; $("#dashShots").textContent=state.shots; $("#dashHeadshots").textContent=state.headshots;
 const best=state.reactions.length?Math.min(...state.reactions):null; $("#dashReaction").textContent=best?best+" ms":"—";
 $("#progressBar").style.width=Math.min(state.xp,100)+"%"; $("#progressText").textContent=state.xp+" / 100 XP";
 $("#statSessions").textContent=state.sessions; $("#statAccuracy").textContent=pct(state.hits,state.shots)+"%"; $("#statBest").textContent=best?best+" ms":"—"; $("#statHS").textContent=state.headshots;
 $("#barAccuracy").style.width=pct(state.hits,state.shots)+"%"; $("#barXP").style.width=Math.min(state.xp,100)+"%";
 $("#ch50").textContent=Math.min(state.challengeHits,50)+" / 50"; $("#ch20").textContent=Math.min(state.challengeHS,20)+" / 20"; $("#chReact").textContent=state.reactionChallenge?"Completed":"Not completed"; $("#xpTotal").textContent=Math.min(state.xp,100);
}
$$(".nav-btn").forEach(b=>b.onclick=()=>showSection(b.dataset.section));
$$("[data-go]").forEach(b=>b.onclick=()=>showSection(b.dataset.go));
function showSection(id){$$(".section").forEach(s=>s.classList.remove("active")); $("#"+id).classList.add("active"); $$(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.section===id)); $("#pageTitle").textContent=id==="hs"?"Headshot Practice":id.split(/(?=[A-Z])/).map(x=>x[0].toUpperCase()+x.slice(1)).join(" "); window.scrollTo({top:0,behavior:"smooth"})}
$("#saveProfile").onclick=()=>{state.nickname=$("#nickname").value.trim()||"Player";state.playerId=$("#playerId").value.trim();save()}
const sensIds=["general","redDot","scope2","scope4","sniper","freeLook"];
sensIds.forEach(id=>$("#"+id).value=state.sensitivity[id]);
$("#saveSens").onclick=()=>{sensIds.forEach(id=>state.sensitivity[id]=Number($("#"+id).value));save();$("#sensSaved").textContent="Saved locally ✓";setTimeout(()=>$("#sensSaved").textContent="",1600)}

let aim={running:false,hits:0,misses:0,score:0,seconds:30,timer:null,target:null};
function renderAim(){ $("#aimHits").textContent=aim.hits;$("#aimMisses").textContent=aim.misses;$("#aimAccuracy").textContent=pct(aim.hits,aim.hits+aim.misses)+"%";$("#aimScore").textContent="Score: "+aim.score;$("#aimTimer").textContent="Time: "+aim.seconds+"s"}
function spawnTarget(){
 if(aim.target)aim.target.remove(); const t=document.createElement("div");t.className="target";t.style.left=(Math.random()*88+4)+"%";t.style.top=(Math.random()*82+5)+"%";
 t.onclick=e=>{e.stopPropagation();aim.hits++;aim.score+=10;state.hits++;state.shots++;state.challengeHits++;state.xp=Math.min(100,state.xp+1);spawnTarget();renderAim();save()};$("#aimArea").appendChild(t);aim.target=t;
}
$("#startAim").onclick=()=>{if(aim.running)return;aim.running=true;$("#aimOverlay").style.display="none";aim.seconds=30;aim.hits=0;aim.misses=0;aim.score=0;spawnTarget();renderAim();clearInterval(aim.timer);aim.timer=setInterval(()=>{aim.seconds--;renderAim();if(aim.seconds<=0)endAim()},1000)}
$("#aimArea").onclick=()=>{if(aim.running){aim.misses++;state.shots++;renderAim();save()}}
function endAim(){clearInterval(aim.timer);aim.running=false;if(aim.target){aim.target.remove();aim.target=null}$("#aimOverlay").style.display="grid";$("#aimOverlay").innerHTML="<h2>Session Complete</h2><p>Score: "+aim.score+" · Accuracy: "+pct(aim.hits,aim.hits+aim.misses)+"%</p><button class='primary' id='startAim'>Start Again</button>";$("#startAim").onclick=()=>location.reload();state.sessions++;save();renderAim()}
$("#restartAim").onclick=()=>{clearInterval(aim.timer);location.reload()};renderAim();

let hsHits=0,hsAttempts=0;
function moveHead(){const a=$("#hsArea"),t=$("#headTarget");t.style.left=(Math.random()*70+15)+"%";t.style.top=(Math.random()*55+15)+"%"}
$("#headTarget").onclick=e=>{e.stopPropagation();hsHits++;hsAttempts++;state.headshots++;state.hits++;state.shots++;state.challengeHS++;state.xp=Math.min(100,state.xp+2);$("#hsScore").textContent=hsHits*10;$("#hsHits").textContent=hsHits;$("#hsAttempts").textContent=hsAttempts;$("#hsAccuracy").textContent=pct(hsHits,hsAttempts)+"%";$("#hsMessage").textContent="💥 HEADSHOT!";moveHead();save()}
$("#hsArea").onclick=()=>{hsAttempts++;state.shots++;$("#hsAttempts").textContent=hsAttempts;$("#hsAccuracy").textContent=pct(hsHits,hsAttempts)+"%";$("#hsMessage").textContent="Miss — aim for the head";save()}
$("#newHS").onclick=()=>{hsHits=0;hsAttempts=0;$("#hsScore").textContent="0";$("#hsHits").textContent="0";$("#hsAttempts").textContent="0";$("#hsAccuracy").textContent="0%";moveHead();$("#hsMessage").textContent="Click the head to score"};

let reactionStart=0,reactionTimer=null,reactionState="idle";
$("#startReaction").onclick=()=>{if(reactionState==="waiting")return;reactionState="waiting";$("#reactionArea").className="reaction-area waiting";$("#reactionText").textContent="WAIT...";$("#reactionResult").textContent="";$("#startReaction").textContent="Get Ready";const delay=1200+Math.random()*2800;clearTimeout(reactionTimer);reactionTimer=setTimeout(()=>{reactionState="go";reactionStart=performance.now();$("#reactionArea").className="reaction-area go";$("#reactionText").textContent="CLICK!";$("#startReaction").textContent="Click the box";},delay)}
$("#reactionArea").onclick=()=>{if(reactionState==="go"){const ms=Math.round(performance.now()-reactionStart);state.reactions.push(ms);state.reactions=state.reactions.slice(-20);state.sessions++;state.xp=Math.min(100,state.xp+(ms<400?8:3));if(ms<400)state.reactionChallenge=true;$("#reactionText").textContent=ms+" ms";$("#reactionResult").textContent=ms<250?"Excellent":ms<350?"Very Good":ms<500?"Good":"Needs Practice";$("#lastReaction").textContent=ms+" ms";$("#bestReaction").textContent=Math.min(...state.reactions)+" ms";reactionState="done";$("#startReaction").textContent="Try Again";$("#reactionArea").className="reaction-area waiting";save()}else if(reactionState==="waiting"){clearTimeout(reactionTimer);reactionState="done";$("#reactionText").textContent="Too Early!";$("#reactionResult").textContent="Wait for CLICK";$("#startReaction").textContent="Try Again"}}
updateUI();