# Headshot Training Panel

A browser-based aim and reaction practice tool.

## Run locally
Open `index.html` in a modern browser.

## GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js` to the repository root.
3. Open Settings -> Pages.
4. Select Deploy from a branch -> `main` -> `/ (root)` -> Save.
5. Open the generated GitHub Pages URL.

This project is a training simulator only. It does not modify Free Fire or provide cheats, aimbots, ESP, anti-cheat bypasses, or game-file changes.
